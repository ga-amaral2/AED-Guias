# n8n Random Node

Conector customizado do **n8n** que gera números randômicos verdadeiros utilizando a API do [Random.org](https://www.random.org/).

## 🚀 Como rodar

### 1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/n8n-random-node.git
cd n8n-random-node
```

### 2. Instale as dependências
```bash
npm install
```

### 3. Build do Node
```bash
npm run build
```

### 4. Suba o ambiente
```bash
docker compose up -d
```

### 5. Teste no n8n
Abra o painel em: [http://localhost:5678](http://localhost:5678)

Você verá o conector **Random** disponível, com a operação **True Random Number Generator**.

## 📂 Estrutura
- `nodes/Random/Random.node.ts` → Lógica do conector
- `nodes/Random/Random.svg` → Ícone
- `docker-compose.yml` → Ambiente com n8n + Postgres
- `.n8n/custom/` → Pasta de conectores customizados dentro do container

## 🧪 Testes
Execute:
```bash
npm test
```

---
Feito com ❤️ usando n8n + Random.org
