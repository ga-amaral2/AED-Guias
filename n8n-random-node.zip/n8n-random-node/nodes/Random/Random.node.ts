import { IExecuteFunctions } from 'n8n-workflow';
import { INodeType, INodeTypeDescription, INodeExecutionData } from 'n8n-workflow';
import axios from 'axios';

export class Random implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Random',
    name: 'random',
    group: ['transform'],
    version: 1,
    description: 'Generate a true random number using Random.org',
    defaults: {
      name: 'Random',
    },
    inputs: ['main'],
    outputs: ['main'],
    icon: 'file:Random.svg',
    properties: [
      {
        displayName: 'Minimum',
        name: 'min',
        type: 'number',
        default: 1,
        description: 'The minimum integer value (inclusive)',
      },
      {
        displayName: 'Maximum',
        name: 'max',
        type: 'number',
        default: 100,
        description: 'The maximum integer value (inclusive)',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const returnData: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const min = this.getNodeParameter('min', i) as number;
      const max = this.getNodeParameter('max', i) as number;

      const url = `https://www.random.org/integers/?num=1&min=${min}&max=${max}&col=1&base=10&format=plain&rnd=new`;
      const response = await axios.get(url);

      returnData.push({
        json: {
          result: parseInt(response.data.trim(), 10),
          min,
          max,
        },
      });
    }

    return [returnData];
  }
}
